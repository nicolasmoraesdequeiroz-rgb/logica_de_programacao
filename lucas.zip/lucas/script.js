// --- LÓGICA DO MODAL DE CADASTRO ---
const authModal = document.getElementById('auth-modal');
const openModalBtns = document.querySelectorAll('.open-auth-modal');
const closeModalBtn = document.querySelector('.close-modal');

// Abrir modal
openModalBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        authModal.classList.add('active');
        // Fechar menu mobile se estiver aberto
        document.getElementById('navLinks').classList.remove('active');
    });
});

// Fechar modal pelo botão X
closeModalBtn.addEventListener('click', () => {
    authModal.classList.remove('active');
});

// Fechar modal ao clicar fora dele
authModal.addEventListener('click', (e) => {
    if (e.target === authModal) {
        authModal.classList.remove('active');
    }
});

// Simulação de envio do formulário
document.getElementById('signup-form').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const inputs = e.target.querySelectorAll('input');
    const password = inputs[2].value;
    const confirmPassword = inputs[3].value;

    if (password !== confirmPassword) {
        alert('As senhas não coincidem! Por favor, verifique.');
        return;
    }

    alert('Conta criada com sucesso! Bem-vindo à NexusPlay.');
    authModal.classList.remove('active');
    e.target.reset();
});


// --- MENU MOBILE ---
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navLinks = document.getElementById('navLinks');

mobileMenuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    const icon = mobileMenuBtn.querySelector('i');
    icon.classList.toggle('fa-bars');
    icon.classList.toggle('fa-times');
});

document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
        mobileMenuBtn.querySelector('i').classList.add('fa-bars');
        mobileMenuBtn.querySelector('i').classList.remove('fa-times');
    });
});


// --- HEADER SCROLL EFFECT ---
window.addEventListener('scroll', () => {
    document.getElementById('header').classList.toggle('scrolled', window.scrollY > 50);
});


// --- ANIMAÇÃO DE SCROLL (INTERSECTION OBSERVER) ---
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => { 
        if (entry.isIntersecting) {
            entry.target.classList.add('show'); 
        }
    });
}, { threshold: 0.1, rootMargin: "0px 0px -50px 0px" });

document.querySelectorAll('.hidden').forEach(el => observer.observe(el));


// --- MANIPULAÇÃO DO FORMULÁRIO DE CONTATO ---
document.getElementById('nexusplay-contact-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const btn = this.querySelector('button[type="submit"]');
    const originalText = btn.innerHTML;
    
    // Simulação de envio
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
    btn.disabled = true;
    
    setTimeout(() => {
        alert('Mensagem enviada com sucesso! Nossa equipe de suporte entrará em contato em breve.');
        this.reset();
        btn.innerHTML = originalText;
        btn.disabled = false;
    }, 1500);
});