let cart = JSON.parse(localStorage.getItem('nexusCart')) || [];
let displayedProducts = 12;

// Mapeamento de imagens reais e condizentes
const productImages = {
    'Notebook': ['https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=400&q=80'],
    'Teclado': ['https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1595225476474-875642f7f948?auto=format&fit=crop&w=400&q=80'],
    'Mouse': ['https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?auto=format&fit=crop&w=400&q=80'],
    'Monitor': ['https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?auto=format&fit=crop&w=400&q=80'],
    'Headset': ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=400&q=80'],
    'Controle': ['https://images.unsplash.com/photo-1605901309584-818e25960a8f?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=400&q=80'],
    'Cadeira': ['https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=400&q=80'],
    'Smartphone': ['https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=400&q=80'],
    'Smartwatch': ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?auto=format&fit=crop&w=400&q=80'],
    'Caixa de Som': ['https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1558486012-816cef68354f?auto=format&fit=crop&w=400&q=80'],
    'Microfone': ['https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=400&q=80']
};

function getProductImage(name) {
    for (const [key, images] of Object.entries(productImages)) {
        if (name.toLowerCase().includes(key.toLowerCase())) return images[Math.floor(Math.random() * images.length)];
    }
    return 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80';
}

function updateCartCount() {
    document.getElementById('cart-count').innerText = cart.reduce((sum, item) => sum + item.quantity, 0);
}

function addToCart(id, name, price, image) {
    const existing = cart.find(item => item.id === id);
    if (existing) existing.quantity += 1;
    else cart.push({ id, name, price, image, quantity: 1 });
    localStorage.setItem('nexusCart', JSON.stringify(cart));
    updateCartCount();
    showCartModal();
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    localStorage.setItem('nexusCart', JSON.stringify(cart));
    updateCartCount();
    renderCartItems();
}

function renderCartItems() {
    const container = document.getElementById('cart-items');
    const totalEl = document.getElementById('cart-total-price');
    if (cart.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: var(--text-muted); padding: 40px;">Seu carrinho está vazio.</p>';
        totalEl.innerText = 'R$ 0,00';
        return;
    }
    let total = 0, html = '';
    cart.forEach(item => {
        total += item.price * item.quantity;
        html += `<div class="cart-item">
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-info">
                <h4>${item.name}</h4>
                <p>R$ ${item.price.toFixed(2).replace('.', ',')} x ${item.quantity}</p>
                <button class="remove-item" onclick="removeFromCart('${item.id}')"><i class="fas fa-trash"></i> Remover</button>
            </div>
        </div>`;
    });
    container.innerHTML = html;
    totalEl.innerText = `R$ ${total.toFixed(2).replace('.', ',')}`;
}

function showCartModal() {
    document.getElementById('cart-modal').classList.add('active');
    renderCartItems();
}

document.getElementById('close-cart')?.addEventListener('click', () => document.getElementById('cart-modal').classList.remove('active'));
document.getElementById('cart-icon')?.addEventListener('click', (e) => { e.preventDefault(); showCartModal(); });

// GERAR EXATAMENTE 50 PRODUTOS
const productContainer = document.getElementById('products-grid');
const categories = ['Informática', 'Games', 'Smartphones', 'Áudio'];
const names = ['Notebook Ultra', 'Teclado Mecânico RGB', 'Mouse Gamer Pro', 'Monitor 144Hz', 'Smartwatch Fit', 'Caixa de Som Bluetooth', 'Microfone Studio', 'Cadeira Gamer Elite', 'Headset Pro', 'Controle Wireless', 'Smartphone Pro'];

let productsHTML = '';
for (let i = 1; i <= 50; i++) {
    const category = categories[Math.floor(Math.random() * categories.length)];
    const name = names[Math.floor(Math.random() * names.length)] + ` ${i}`;
    const price = (Math.random() * 800 + 99).toFixed(2);
    const oldPrice = (parseFloat(price) * 1.3).toFixed(2);
    const isPromo = Math.random() > 0.7;
    const image = getProductImage(name);

    productsHTML += `<div class="product-card hidden" data-category="${category}">
        ${isPromo ? '<span class="promo-badge">-30%</span>' : ''}
        <div class="product-image"><img src="${image}" alt="${name}" loading="lazy"></div>
        <div class="product-info">
            <span class="product-category">${category}</span>
            <h3>${name}</h3>
            <div class="product-price">
                ${isPromo ? `<span class="old-price">R$ ${oldPrice}</span>` : ''}
                <span class="current-price">R$ ${price}</span>
            </div>
            <button class="btn-add" onclick="addToCart('${i}', '${name}', ${price}, '${image}')"><i class="fas fa-cart-plus"></i> Adicionar</button>
        </div>
    </div>`;
}
productContainer.innerHTML = productsHTML;

document.getElementById('load-more-btn')?.addEventListener('click', () => {
    const hiddenProducts = document.querySelectorAll('.product-card.hidden');
    let count = 0;
    hiddenProducts.forEach((product, index) => {
        if (count < 12) { setTimeout(() => product.classList.add('show'), index * 50); count++; }
    });
    if (hiddenProducts.length <= 12) document.getElementById('load-more-btn').style.display = 'none';
});

// TEMA CLARO/ESCURO
const themeToggle = document.getElementById('theme-toggle');
const savedTheme = localStorage.getItem('nexusTheme') || 'dark';
if (savedTheme === 'light') { document.body.classList.add('light-mode'); themeToggle.innerHTML = '<i class="fas fa-sun"></i>'; }
themeToggle?.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
    const isLight = document.body.classList.contains('light-mode');
    localStorage.setItem('nexusTheme', isLight ? 'light' : 'dark');
    themeToggle.innerHTML = isLight ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
});

// COUNTDOWN PROMOÇÃO
function checkPromo() {
    const promoBanner = document.getElementById('promo-banner');
    const promoEnded = document.getElementById('promo-ended');
    let endDateStr = localStorage.getItem('nexusPromoEnd');
    if (!endDateStr) {
        const future = new Date(); future.setHours(future.getHours() + 24);
        endDateStr = future.toISOString();
        localStorage.setItem('nexusPromoEnd', endDateStr);
    }
    const now = new Date();
    const end = new Date(endDateStr);
    const diff = end - now;
    
    if (diff <= 0) {
        promoBanner.style.display = 'none';
        promoEnded.style.display = 'flex';
        promoEnded.classList.remove('hidden');
        promoEnded.classList.add('show');
        return;
    }
    promoEnded.style.display = 'none';
    promoBanner.classList.remove('hidden');
    promoBanner.classList.add('show');
    
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    document.getElementById('hours').innerText = hours.toString().padStart(2, '0');
    document.getElementById('minutes').innerText = minutes.toString().padStart(2, '0');
    document.getElementById('seconds').innerText = seconds.toString().padStart(2, '0');
}
setInterval(checkPromo, 1000);
checkPromo();

// UI: Menu, Scroll, Animações
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navLinks = document.getElementById('navLinks');
mobileMenuBtn?.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    const icon = mobileMenuBtn.querySelector('i');
    icon.classList.toggle('fa-bars');
    icon.classList.toggle('fa-times');
});
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
        mobileMenuBtn.querySelector('i').classList.add('fa-bars');
        mobileMenuBtn.querySelector('i').classList.remove('fa-times');
    });
});
window.addEventListener('scroll', () => document.getElementById('header').classList.toggle('scrolled', window.scrollY > 50));

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add('show'); });
}, { threshold: 0.1, rootMargin: "0px 0px -50px 0px" });
document.querySelectorAll('.hidden').forEach(el => observer.observe(el));

// APLICAR CONFIGURAÇÕES DO ADMIN
function applyAdminSettings() {
    const settings = JSON.parse(localStorage.getItem('nexusSettings') || '{}');
    if (settings.heroTitle) document.getElementById('hero-title-display').innerHTML = settings.heroTitle;
    if (settings.heroSubtitle) document.getElementById('hero-subtitle-display').innerText = settings.heroSubtitle;
    if (settings.storeEmail) document.getElementById('display-email').innerText = settings.storeEmail;
    if (settings.storePhone) document.getElementById('display-phone').innerText = settings.storePhone;
    if (settings.storeAddress) document.getElementById('display-address').innerText = settings.storeAddress;
    if (settings.primaryColor) document.documentElement.style.setProperty('--primary', settings.primaryColor);
}
applyAdminSettings();
updateCartCount();

setTimeout(() => {
    document.querySelectorAll('.product-card').forEach((el, i) => { if (i < displayedProducts) el.classList.add('show'); });
}, 300);

// FORMULÁRIO DE CONTATO
document.getElementById('contact-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
    btn.disabled = true;
    setTimeout(() => {
        alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
        this.reset();
        btn.innerHTML = originalText;
        btn.disabled = false;
    }, 1500);
});